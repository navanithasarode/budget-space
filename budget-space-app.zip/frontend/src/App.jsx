import { Navigate, Route, Routes } from "react-router-dom";
import { AppProvider } from "./context/AppContext";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import BudgetDetails from "./pages/BudgetDetails";
import CreateBudget from "./pages/CreateBudget";
import Login from "./pages/Login";
import Register from "./pages/Register";

function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/register" element={<Register />} />
      <Route element={<Layout />}>
        <Route path="/" element={<Dashboard />} />
        <Route path="/budgets/new" element={<CreateBudget />} />
        <Route path="/budgets/:id" element={<BudgetDetails />} />
        <Route path="*" element={<Navigate to="/" replace />} />
      </Route>
    </Routes>
  );
}

export default function App() {
  return <AppProvider><AppRoutes /></AppProvider>;
}
