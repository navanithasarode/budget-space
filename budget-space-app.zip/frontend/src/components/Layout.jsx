import { NavLink, Outlet } from "react-router-dom";
import { useApp } from "../context/AppContext";

export default function Layout() {
  const { mode, user, logout } = useApp();
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="brand-mark">₹</div>
          <div><strong>Budget Space</strong><span>money for real life</span></div>
        </div>
        <nav>
          <NavLink to="/" end>Overview</NavLink>
          <NavLink to="/budgets/new">+ New Budget Space</NavLink>
        </nav>
        <div className="sidebar-bottom">
          <div className="mode-pill">{mode === "demo" ? "Demo mode" : "Connected"}</div>
          {user ? <button className="text-button" onClick={logout}>Log out</button> : <NavLink to="/login">Log in</NavLink>}
        </div>
      </aside>
      <main className="main"><Outlet /></main>
    </div>
  );
}
